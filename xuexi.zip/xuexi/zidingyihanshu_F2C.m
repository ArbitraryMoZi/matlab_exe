formation C = F2C ( F ) 
while true
    input( 'Temperature in F:  ' );
    C = ( F - 32 ) * 5 / 9;
    if isempty( F )
        break;
    end
end